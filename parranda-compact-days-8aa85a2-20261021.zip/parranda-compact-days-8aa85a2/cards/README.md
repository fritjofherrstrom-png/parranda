# Compact stop cards — local component evidence

Base: `0643bc56202a8d1d552ea09e302a0bb0a1cd2aca`. This is working-tree evidence; the parent integration owns the final exact SHA, build/dist and full-suite freeze.

Changed six frontend source/test files only. Unknown hours are inside the expanded stop only; known closed facts stay visible. Source-kind/address detail comes from bounded `place_details`; a full match line uses only selected server `covered_preferences`, excluding partials. Existing editing handlers remain unchanged, grouped in a compact control row. Maps/Website become secondary links and provenance stays in a real disclosure.

RED→GREEN: `red.log` is 21 PASS / 11 FAIL; `green.log` 32/32 PASS. Additional `place_details` RED had three failures; its GREEN is 35/35. A legacy/null boundary was then added and caught a helper fault (`legacy-details-red.log`); fixed before the final run.

Final affected verification: **178 PASS, 0 FAIL, 0 SKIP** (`final-focused.log`) plus typecheck PASS (`typecheck.log`). `RESULTS.json` carries counts per run. Final command:

```sh
node --test frontend/tests/planner-stop-hours.test.mjs frontend/tests/planner-line-facts.test.mjs frontend/tests/stop-card-facts.test.mjs frontend/tests/planner-stop-edit.test.mjs frontend/tests/planner-commitment-races.test.mjs frontend/tests/planner-url-reload-choices.test.mjs frontend/tests/commitment-persistence.test.mjs frontend/tests/planner-live-controls.test.mjs frontend/tests/planner-live-selection.test.mjs frontend/tests/planner-a11y-hierarchy.test.mjs
npm run check:frontend
```

This mounts real Planner/UI state with controlled API responses and clocks. It verifies rendering, Keep/Replace/Remove/reload, late response guards, persistence, Live selection and accessibility hierarchy. It does not prove actual provider freshness, correct business identity, real opening hours, street-network distance, physical Safari, or public acceptance. No source/provider call, commit, dist rebuild, push, merge or deployment was made by this subtask.
