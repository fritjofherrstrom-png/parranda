# Vad ett generellt tvåkällskrav skulle kosta

**Jag rekommenderar inte att slå på ett generellt tvåkällskrav. Det skulle i detta sparade underlag kasta bort många plausibla butiker tillsammans med felposterna. Rätta belagda konflikter och förbättra uppgifter om de valda platserna först. Ingen regel har ändrats.**

Läsande kontroll den 21 oktober 2026 från main `0643bc56202a8d1d552ea09e302a0bb0a1cd2aca`. Inga produktanrop, producentstarter, cacheändringar, kodändringar eller deployer. Befintliga Pi-filer lästes direkt; begränsade externa kontroller gällde verksamheternas egna webbplatser. Filerna i detta paket innehåller inga nycklar eller privata konfigurationer.

## Mätningen

| Sparat underlag | Second hand-/antikposter från Overture | Poster som faktiskt kan identitetsmatchas mot den befintliga OSM-kopian | Kvar vid ett enkelt krav på två matchade källfamiljer |
| --- | ---: | ---: | ---: |
| Prags centrala ankare `50.0874654,14.4212535` | 42 | 1 | 1 av 42 |
| Holešovices ankare `50.1028733,14.4402734` | 40 | 1 | 1 av 40 |

Detta är **katalogposter som potentiellt kan bidra**, inte 42 eller 40 publicerade stopp och inte en ny publik acceptanskörning. Den befintliga OSM-kopian innehåller åtta vintageposter och hör till centrala Prag; den är inte en ny komplett insamling av Holešovice. Den enda matchen är Antique Cinolter, fem meter mellan punkterna och exakt namnmatchning. Beräkningen kör den verkliga, konservativa `mapRecordToCandidate` och `matchIdentity` utan nätverk. Se [reproducerbart skript](REPRODUCE_OFFLINE.cjs) och [samtliga resultat](offline-retained-identity-matches.json).

**Två familjer är dessutom inte samma sak som två aktuella oberoende källor.** OSM-kopian gick ut den 20 oktober kl. 07.29 UTC. Overtures underliggande dataleverantörer är inte bevarade för dessa poster, så det är inte bevisat att katalogen inte återanvänder samma ursprung. Därför är **0 platser styrkta som godkända enligt ett strikt krav på två aktuella, oberoende platskällor** i detta avgränsade underlag. Det är brist på bevis, inte bevis på att alla platser är dåliga.

Katalogkopian för Holešovice hämtades den 21 oktober kl. 11.59 UTC; centrets kopia hämtades den 20 oktober och versionsverifierades den 21 oktober. Båda avser Overture-release `2026-09-23.1`. Att hämta eller verifiera septemberversionen i dag bevisar inte att varje butik fortfarande finns.

## Konkreta platser

ID-suffix visas här; fullständiga ID:n, koordinater, källfamiljer och webbadresser finns i [TRADEOFF_RESULTS.json](TRADEOFF_RESULTS.json). I produktens sparade katalog har alla en enda `open_directory`-familj. Nedan ges ytterligare fakta från läsande research; de har inte förts in i produkten som nya källbelägg.

| Plats / ID-suffix | Sparat stöd och hypotetiskt tvåfamiljsutfall | Vad förstahandskontrollen faktiskt visar |
| --- | --- | --- |
| **Cesta Domů** / `0e904724…1d0b` | En katalogfamilj. **Avvisas.** | [Operatören listar](https://www.cestadomu.cz/obchody) sin second hand-/välgörenhetsbutik på **Bubenská 3, Holešovice**, vardagstider och en nyhet daterad 15 oktober 2026. Ingen permanent stängning belagd. Detta är en konkret butik med aktuellt förstahandsstöd som ett rent krav på redan insamlade två familjer skulle tappa. Fysisk öppning i dag är inte besöksverifierad. |
| **Recycle Store** / `c4f9901e…cdf8` | En katalogfamilj. **Avvisas.** | [Egen butikssida](https://www.recyclestore.cz/) visar omarbetade kläder och adress **Veverkova 8, Praha 7**. Det är positivt butiksstöd, men ett fungerande e-handelssystem bevisar inte att dörren till den fysiska butiken är öppen just nu. |
| **Sue Ryder, Heřmanka** / `fdc7c9ad…c735` | En katalogfamilj. **Avvisas.** | [Operatörens filiallista](https://www.sue-ryder.cz/clanky/navstivte-nas) anger **Heřmanova 596/59, Praha 7**, välgörenhetsbutik och veckotider. Den äldre sparade länken på samma domän gick inte att hämta; den aktuella filiallistan stöder platsen. Ett trasigt äldre URL-spår bevisar alltså inte nedläggning. |
| **SecondhandPrague.cz** / `3c67fad6…a51a` | En katalogfamilj. Närliggande OSM-post `Praha Thrift Store` matchas **inte** av produktens nuvarande namn-/identitetsregler. **Avvisas.** | [Operatörens platssida](https://www.thriftshop.cz/shop/contact-2) anger fortfarande butiken **Dukelských Hrdinů 21** och länkar till SecondhandPrague.cz som sin e-handel. Två operatörsdomäner är en ägare, inte två oberoende bekräftelser. Permanent stängning är inte belagd av denna kontroll; webbplatsen kan själv vara inaktuell. Användarens observation ska följas upp, inte avfärdas med att sidan svarar. |
| **Antik Ambra** / `0064c359…26c3` | En katalogfamilj. OSM:s `Galerie Antik Ambra` ligger elva meter bort men identitetsmatcharen håller isär namnen. **Avvisas.** | [Operatörens indexerade text](https://www.antikambra.eu/o-nas/) inbjuder till **ny adress Kaprova 40/12**; den sparade OSM-adressen är Kaprova 14. Direkthämtning gav omdirigeringsloop. Verksamheten har positivt stöd men fysisk gammal/ny adress behöver förenas. Inte säker användbarhet för den gamla punkten. |
| **Antique Cinolter** / `4592fb2f…7c0f` | Overture plus identitetsmatchad OSM. **Kvar i ett förenklat tvåfamiljsprov.** | Matchningen är verklig och fem meter. Operatörssidan kunde inte hämtas. Oberoende ursprung, aktuella öppettider och frisk fysisk verksamhet är **inte** bevisade bara för att två familjer finns. |
| **Flat Service** / `537a9f68…ab08` | En katalogfamilj. **Avvisas.** | [Den länkade verksamheten](https://flatservice.cz/o-nas/) beskriver fastighets-/uthyrningsförvaltning på **Pařížská 1073/1**, inte belagd second hand-handel. Konkret konflikt med produktens `vintage-shop`/`second_hand`. Rå taxonomi saknas; fel i originalklassning kontra tidigare mappning är ännu inte åtskilda. |
| **HAVEX-auto, Holešovice** / `a68426f5…a329` | En katalogfamilj. **Avvisas.** | [Den exakta länkade filialen](https://www.havex.cz/cz/praha-holesovice-jatecni) anger **Jateční 317/41**, egna koordinater nära katalogpunkten och tjänsterna bilservice, reservdelar och tillbehör. Även denna har sparats som Second hand. Det finns alltså konkret kategoriförorening utöver Flat Service. Ingen nedläggning behöver antas för att förklara att detta är ett dåligt preferensförslag. |

**Minst tre konkreta Holešoviceexempel — Cesta Domů, Recycle Store och Sue Ryder — har positivt aktuellt förstahandsstöd men skulle försvinna om redan insamlade två källfamiljer krävdes.** Det är den praktiska förlusten vi kan visa. Vi har inte gjort ett fysiskt besök i någon av dem och anger därför inte ett bevisat antal butiker som faktiskt är öppna i detta ögonblick.

## Slutsats och bättre avgränsning

Ett numeriskt tvåkällskrav gör varken koordinater, verksamhetstyp eller öppettider sanna. Två kataloger kan återanvända samma fel; en riktig butiks egen sida kan vara bättre stöd än flera kopior. Flat Service och HAVEX kan få sin existens bekräftad på operatörssidorna samtidigt som **deras Second hand-matchning motsägs**. Att räkna existensbekräftelser utan att pröva den relevanta egenskapen löser inte det felet.

Behåll därför dagens antagningspolicy under detta uppdrag. En rimlig följande förbättring är identitetsbunden komplettering av **redan valda** platser med adress, faktisk verksamhet och tydliga negativa fakta, där det finns en säker förstahandskoppling. Ett belagt filialbyte, stängningsbesked eller kategorifel ska kunna rättas utan att alla ensamma katalogposter underkänns. Saknade uppgifter och ett misslyckat webbuppslag ska fortsatt vara okända.

Detta uppdrag bevisar **inte** påståendet att nästan allt i den visade Holešovicerutten är permanent stängt. Hela skärmbildens publicerade svar/ID-lista saknas i denna delkontroll. Inga verifierade förstahandsbesked om permanent stängning hittades i den begränsade kontrollen. Det bevisar inte heller motsatsen. Däremot är kategorifel, gammal adressinformation, otillräcklig källidentitet och en stor potentiell täckningsförlust vid en generell grind konkret visade.

## Filer och återkörning

- `retained-prague-second-hand.json`: sanerade direktlästa katalogposter och versionskvitton för tre befintliga ankare; endast vintageposter.
- `retained-prague-map-second-hand.json`: befintliga åtta vintageposter från centrets kartcache, inklusive utgångstid.
- `offline-retained-identity-matches.json`, `selected-pair-identity-verdicts.json`: produktens faktiska identitetsbedömningar på de sparade underlagen.
- `TRADEOFF_RESULTS.json`: maskinläsbara antal, exakta ID:n, faktiska primärlänkar och evidensgränser.
- `REPRODUCE_OFFLINE.cjs`: kör med `node REPRODUCE_OFFLINE.cjs /absolut/sökväg/till/repo`. Läser bara två lokala JSON-filer och produktens rena mappare/matchare. Ingen provider, producent eller cache anropas.

Runtime för offlinekontrollen: lokal Node/macOS arm64; detta är inte Node22/arm64-Pi-acceptans, fullsvit eller publik ruttacceptans. Inga nya tester eller produktfiler tillkom.
