// Read-only replay of retained source records through the real identity matcher.
// Does not invoke source loaders or network. Pass the frozen repository root.
const fs = require('node:fs');
const path = require('node:path');
const repo = process.argv[2];
if (!repo) throw new Error('Pass a repository root');
const { matchIdentity } = require(path.join(repo, 'server/candidates/entity-resolution'));
const { mapRecordToCandidate } = require(path.join(repo, 'server/place-candidates/external-open-provider'));
const catalogues = JSON.parse(fs.readFileSync(path.join(__dirname, 'retained-prague-second-hand.json')));
const maps = JSON.parse(fs.readFileSync(path.join(__dirname, 'retained-prague-map-second-hand.json')))[0].records;
const candidate = r => mapRecordToCandidate({key:'audit-prague'}, r, '2026-10-21T13:00:00Z', 0);
for (const sample of catalogues.filter(s => s.file.startsWith('50.102') || s.file.startsWith('50.087'))) {
  const hits = sample.records.filter(r => maps.some(m => matchIdentity(candidate(r), candidate(m)).same));
  console.log(JSON.stringify({sample:sample.file,catalogue_records:sample.records.length,map_records:maps.length,identity_matched_catalogue_records:hits.length,surviving_ids:hits.map(r=>r.id)}));
}
