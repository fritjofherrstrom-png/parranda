'use strict';
// Controlled read-only diagnosis. Product chooser output is never replaced.
// Sources, clock and weather are fixtures; no external provider acceptance.
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { execFileSync } = require('node:child_process');
const repo = process.argv[2];
if (!repo) throw new Error('Pass the absolute repository path');
const chooser = require(path.join(repo, 'server/planner/agnostic-candidate-set'));
const originalChooser = chooser.selectAgnosticCandidateSet;
let activeRhythm = null;
const traces = [];
chooser.selectAgnosticCandidateSet = function (args) {
  const actual = originalChooser(args);
  if (args.targetKm === 6 && args.desiredCount === 4) {
    // Counterfactual shares the exact admitted pool, evidence, count and context.
    // Only the internal target argument differs. It is observed, never returned.
    const counterfactual = originalChooser({ ...args, targetKm: null });
    const describe = result => ({ ids: result.selected.map(stop => stop.id),
      km: result.diagnostics.estimated_km, longest_leg_km: result.diagnostics.longest_leg_km });
    traces.push({ rhythm: activeRhythm, targetKm: args.targetKm,
      actual: describe(actual), counterfactual_no_target: describe(counterfactual) });
  }
  return actual;
};
const { buildApp } = require(path.join(repo, 'server/app'));
const { mapOsmElement } = require(path.join(repo, 'server/place-candidates/open-data-loader'));
const { requestJson, mockStableWeatherFetch } = require(path.join(repo, 'tests/helpers/planner-reservoir-compare'));

(async () => {
  const { buildAnywherePayload } = await import(pathToFileURL(path.join(repo, 'frontend/src/lib/anywhere-payload.mjs')));
  const deltas = [0, 0.001, 0.002, 0.003, 0.020, 0.027];
  const rows = deltas.flatMap((delta, i) => {
    const lat = 55.6 + delta, lng = 13, name = `Fixture Reuse ${i}`;
    return [mapOsmElement({ type: 'node', id: 9900 + i, lat, lon: lng,
      tags: { name, shop: 'second_hand', opening_hours: 'Mo-Su 10:00-18:00' } }),
    { id: `directory-${i}`, name, type: 'vintage-shop', lat, lng,
      sources: [{ provider: 'directory', family: 'open_directory', tier: 'inferred',
        url: `https://directory.example/store/${i}` }] }];
  });
  const oldFetch = global.fetch;
  global.fetch = mockStableWeatherFetch();
  const server = buildApp({ openDataLoader: async () => rows,
    weatherProvider: async () => ({ condition: 'sun', maxTemp: 20,
      timezone_resolution: { timezone: 'Europe/Stockholm', timezone_source: 'weather_provider_auto', utc_offset_seconds: 7200 } }),
    clock: () => new Date('2026-10-01T08:00:00Z'),
  }).listen(0);
  const results = [];
  try {
    for (const dayRhythm of ['calm', 'balanced', 'full']) {
      activeRhythm = dayRhythm;
      const body = buildAnywherePayload({ coords: { lat: 55.6, lng: 13 },
        dates: ['2026-10-08'], preferences: ['second_hand'], dayRhythm });
      const response = await requestJson(server, { path: '/api/route-recommendations?lang=en', body });
      const route = response.body.days[0]?.primary_route;
      results.push({ rhythm: dayRhythm, request: body, http_status: response.status,
        published: route ? { count: route.main_stops.length, ids: route.main_stops.map(stop => stop.id),
          km: route.estimated_km, longest_leg_km: route.longest_leg_km } : null });
    }
    const receipt = { base_head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim(),
      working_tree: execFileSync('git', ['status', '--short'], { cwd: repo, encoding: 'utf8' }).trim(),
      route_engine_sha256: require('node:crypto').createHash('sha256').update(fs.readFileSync(path.join(repo, 'server/route-engine.js'))).digest('hex'),
      runtime: { node: process.version, platform: process.platform, arch: process.arch },
      scope: 'Controlled local real HTTP/handlers and engine; fixture sources, weather and clock; no provider calls; no built UI.',
      evidence: 'Chooser instrumentation observes actual arguments and computes a separate no-target counterfactual; actual product result is returned unchanged.',
      deltas_latitude: deltas, results, traces };
    const output = JSON.stringify(receipt, null, 2) + '\n';
    fs.writeFileSync(path.join(__dirname, 'rhythm-replay-result.json'), output);
    process.stdout.write(output);
  } finally {
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
    global.fetch = oldFetch;
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
