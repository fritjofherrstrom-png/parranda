# Compact rhythm fix — focused evidence

Base: `0643bc56202a8d1d552ea09e302a0bb0a1cd2aca`. Shared integration branch: `codex/compact-days-place-cards-20261021`. This subtask leaves uncommitted changes for the integration owner; no candidate SHA, commit, push, merge, build-dist or deploy is claimed here.

## Production delta

Only the agnostic complete-set chooser section in `server/route-engine.js` changed for this subtask. For `distanceMode === 'no_limit'`, both complete-set selection and preference-priority selection receive `targetKm: null`. The numeric engine fallback remains available to unrelated internal calculations and explicit legacy walking-target requests retain their existing target. No radius, source eligibility, trust, opening-hours, pin, edit or walking-safety policy changed.

The no-target chooser already compares compactness and longest leg among otherwise equivalent useful sets. The fix lets that existing policy run instead of accidentally favouring a 6km target band.

## RED → GREEN

Command:

```sh
node --require ./tests/helpers/no-live-network.js --require ./tests/helpers/file-deadline.js --test --test-timeout=600000 tests/day-rhythm-compactness.test.js
```

- `red.log`: 2 FAIL, 1 PASS before production changes. The Relaxed route selected farther fixture `directory-4` instead of compact `directory-3`; its 5.4km route was longer than the 5.3km Balanced route. Explicit legacy 6km control passed.
- `green.log`: the original 3 tests PASS after the minimal production change.
- Final file adds two existing-contract guards: closed/wrong-interest/unattributed/knowledge-only places cannot buy compactness; a usable farther Keep retains its identity and honest walking cost through repeated HTTP composition.
- `green-guards.log` records one invalid initial test expectation: it assumed Keep must retain exactly four stops. Inspection of the existing `applyPinnedSelection` contract showed that a missing admitted pin is deliberately appended. The final guard independently asserts the four compact choices plus the explicit farther pin (five identities). Production pin logic was unchanged. This is not a product failure hidden by altering its policy.

## Focused regressions

`focused-regressions.log`: **169 PASS, 0 FAIL, 0 SKIP**, 100.7 seconds.

```sh
node --require ./tests/helpers/no-live-network.js --require ./tests/helpers/file-deadline.js --test --test-timeout=600000 \
  tests/day-rhythm-compactness.test.js tests/day-rhythm-composition.test.js tests/day-rhythm-engine.test.js \
  tests/agnostic-candidate-set.test.js tests/rhythm-density.test.js tests/day-composition-priority.test.js \
  tests/day-composition-stop-edit.test.js tests/day-composition-live-keep.test.js \
  tests/day-composition-publication.test.js tests/day-composition-replay.test.js \
  tests/pinned-candidates.test.js tests/pin-walking-budget.test.js \
  tests/agnostic-route-walking-validation.test.js tests/walking-fit-selection.test.js \
  tests/walking-budget-switch.test.js
```

These include explicit kilometre targets and walking checks, 4/5/6 density, source/admission/closed-place guards, priority, pins, manual edits, Live-kept occurrences, publication and retained-context replay. Root owns the final full suite, built browser integration and exact candidate verification.

## Runtime replay

`rhythm-replay.cjs` and `rhythm-replay-result.json` preserve the controlled real HTTP route outputs after the change:

| Rhythm | Published stops | Estimated km | Longest leg km |
| --- | ---: | ---: | ---: |
| Relaxed | 4 | 0.7 | 0.4 |
| Balanced | 5 | 5.3 | 2.4 |
| Full | 6 | 7.3 | 3.3 |

The four compact and two farther fixtures have the same relevant type and equivalent source evidence. Clock, source records and weather are controlled. No live provider calls or public acceptance. Node v24.15.0, Darwin arm64, versus deployed Node22/Linux arm64. The replay receipt labels the uncommitted working tree and fingerprints `route-engine.js`; it is not mislabelled as an exact committed release.

The earlier unchanged-product diagnosis and chooser-only counterfactual remain preserved separately in `/Users/fritjof/Developer/parranda-evidence/stop-card-rhythm-diagnosis-20261021`. The fixed replay now contains actual published routes, not just the chooser counterfactual.

## Limits

This proves that the reproduced unnecessary stretch is removed while the covered contracts remain green. It does not promise that Relaxed is always shorter than Balanced across differing pins, supply, preferences or availability. Existing routing distances remain estimates; no new street-network acceptance, provider health or public QA is claimed.
