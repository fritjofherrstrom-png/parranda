'use strict';
// Observes the original test without changing its fixtures, requests, waits,
// browser arguments or result. Capture happens before context cleanup.
if (process.env.NODE_TEST_CONTEXT && process.env.PARRANDA_DIAG_RUN_DIR && /unified-city-planner-browser\.test\.js$/.test(process.argv[1] || '')) {
  const fs=require('node:fs');
  const path=require('node:path');
  const {chromium}=require(path.join(process.env.PARRANDA_DIAG_DEPENDENCIES,'playwright-core'));
  const dir=process.env.PARRANDA_DIAG_RUN_DIR;
  fs.mkdirSync(dir,{recursive:true});
  const events=[];
  const started=performance.now();
  const mark=(type,data={})=>events.push({ms:Math.round(performance.now()-started),type,...data});
  let count=0;
  function safeUrl(raw) {
    try { const u=new URL(raw); for(const key of u.searchParams.keys()) if(/token|key|secret|auth|password/i.test(key)) u.searchParams.set(key,'[redacted]'); return u.toString(); }
    catch{return String(raw).slice(0,250);}
  }
  const launch=chromium.launch.bind(chromium);
  chromium.launch=async options=>{
    mark('browser_launch',{args:options?.args,headless:options?.headless});
    const browser=await launch(options);
    mark('browser_ready',{version:browser.version()});
    const newContext=browser.newContext.bind(browser);
    browser.newContext=async (...args)=>{
      const ctx=await newContext(...args);
      const index=++count;
      ctx.on('page',page=>{
        mark('page_created',{index});
        page.on('console',msg=>{if(['error','warning'].includes(msg.type()))mark('console',{index,level:msg.type(),text:msg.text().slice(0,2500)});});
        page.on('pageerror',err=>mark('pageerror',{index,text:err.message}));
        page.on('requestfailed',req=>mark('requestfailed',{index,url:safeUrl(req.url()),failure:req.failure()}));
        page.on('response',res=>{ if(/\/api\/|\/_astro\/|\/rome(?:\?|$)|\/anywhere/.test(res.url())) mark('response',{index,url:safeUrl(res.url()),status:res.status()}); });
        page.on('domcontentloaded',()=>mark('domcontentloaded',{index,url:safeUrl(page.url())}));
      });
      await ctx.addInitScript(()=>{
        const state={markerChanges:[],contextEvents:[]};
        window.__romeDiag=state;
        let oldCount=-1;
        const check=()=>{
          const count=document.querySelectorAll('.route-map-marker').length;
          if(count!==oldCount){oldCount=count;state.markerChanges.push({ms:performance.now(),count});}
        };
        document.addEventListener('webglcontextlost',()=>state.contextEvents.push({event:'lost',ms:performance.now()}),true);
        document.addEventListener('webglcontextrestored',()=>state.contextEvents.push({event:'restored',ms:performance.now()}),true);
        document.addEventListener('DOMContentLoaded',()=>{check();new MutationObserver(check).observe(document.documentElement,{childList:true,subtree:true});});
      });
      const close=ctx.close.bind(ctx);
      ctx.close=async (...args)=>{
        for(const [number,page] of ctx.pages().entries()){
          try {
            let captureTimer;
            const data=await Promise.race([page.evaluate(()=>{
              const rect=e=>{const r=e.getBoundingClientRect();const s=getComputedStyle(e);return{x:r.x,y:r.y,width:r.width,height:r.height,display:s.display,visibility:s.visibility};};
              const canvas=document.querySelector('.maplibregl-canvas');
              const gl=canvas?.getContext('webgl2');
              const ext=gl?.getExtension('WEBGL_debug_renderer_info');
              return{url:location.href,body:document.body.innerText.slice(0,18000),markers:[...document.querySelectorAll('.route-map-marker')].map(e=>({text:e.textContent,...rect(e)})),canvas:canvas?{...rect(canvas),glContextLost:gl?.isContextLost(),renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):null}:null,observations:window.__romeDiag,resources:performance.getEntriesByType('resource').map(r=>({name:r.name,startTime:r.startTime,duration:r.duration,transferSize:r.transferSize})),readyState:document.readyState};
            }),new Promise((_,reject)=>{captureTimer=setTimeout(()=>reject(new Error('diagnostic_capture_timeout')),5000);})]).finally(()=>clearTimeout(captureTimer));
            fs.writeFileSync(path.join(dir,`page-${index}-${number}.json`),JSON.stringify(data,null,2));
            await page.screenshot({path:path.join(dir,`page-${index}-${number}.png`),fullPage:true,timeout:5000}).catch(error=>mark('screenshot_error',{index,text:error.message.slice(0,300)}));
            mark('page_captured',{index,markers:data.markers.length});
          }catch(error){mark('capture_error',{index,text:error.message.slice(0,500)});}
        }
        fs.writeFileSync(path.join(dir,'browser-events.json'),JSON.stringify(events,null,2));
        return close(...args);
      };
      return ctx;
    };
    return browser;
  };
}
