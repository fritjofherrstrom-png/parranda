'use strict';
// External observer: retains original fixture, browser arguments, waits and
// audit return values. No CSS/DOM mutation, added wait or extra request.
if (process.env.NODE_TEST_CONTEXT && process.env.PARRANDA_PULSE_DIAG_DIR && /pulse-contrast\.test\.js$/.test(process.argv[1] || '')) {
  const fs = require('node:fs');
  const path = require('node:path');
  const crypto = require('node:crypto');
  const { chromium } = require(path.join(process.env.PARRANDA_DIAG_DEPENDENCIES, 'playwright-core'));
  const dir = process.env.PARRANDA_PULSE_DIAG_DIR;
  fs.mkdirSync(dir, { recursive: true });
  let index = 0;
  const launch = chromium.launch.bind(chromium);
  chromium.launch = async (...args) => {
    const browser = await launch(...args);
    const newContext = browser.newContext.bind(browser);
    browser.newContext = async (...args) => {
      const ctx = await newContext(...args);
      const id = ++index;
      const events = [], bodies = [];
      const started = performance.now();
      const mark = (type, data = {}) => events.push({ ms: performance.now() - started, type, ...data });
      await ctx.addInitScript(() => {
        window.__pulseDiag = { states: [], initialization: [] };
        for (const name of ['DOMContentLoaded', 'load', 'scrollend']) addEventListener(name, () => {
          window.__pulseDiag.initialization.push({ name, ms: performance.now(), readyState: document.readyState, scrollX, scrollY });
        });
      });
      ctx.on('page', page => {
        page.on('console', msg => mark('console', { level: msg.type(), text: msg.text() }));
        page.on('pageerror', error => mark('pageerror', { text: error.message }));
        page.on('requestfailed', request => mark('requestfailed', { url: request.url(), error: request.failure() }));
        page.on('response', response => {
          mark('response', { url: response.url(), status: response.status() });
          if (/\/(styles\.css|script\.js)(\?|$)/.test(response.url())) bodies.push(response.body().then(body => {
            const name = new URL(response.url()).pathname.split('/').at(-1);
            fs.writeFileSync(path.join(dir, `page-${id}-${name}`), body);
            mark('loaded_asset', { name, bytes: body.length, sha256: crypto.createHash('sha256').update(body).digest('hex') });
          }).catch(error => mark('asset_error', { text: error.message })));
        });
        const evaluate = page.evaluate.bind(page);
        page.evaluate = async (fn, arg) => {
          if (typeof fn !== 'function' || fn.name !== 'collectTexts') return evaluate(fn, arg);
          const result = await evaluate(({ source, arg }) => {
            const result = (0, eval)(`(${source})`)(arg);
            const describe = e => `${e.tagName}${e.id ? '#' + e.id : ''}.${[...e.classList].join('.')}`;
            const geometry = e => {
              const rect = e.getBoundingClientRect(), css = getComputedStyle(e);
              return { element: describe(e), rect: rect.toJSON(), scrollLeft: e.scrollLeft, scrollTop: e.scrollTop, scrollWidth: e.scrollWidth, clientWidth: e.clientWidth, css: Object.fromEntries(['display','visibility','position','transform','translate','background','color','width','padding','margin','overflow','scrollBehavior','fontFamily'].map(k => [k, css[k]])) };
            };
            const roots = arg.map(selector => {
              const root = document.querySelector(selector);
              const ancestors = []; for (let e = root; e; e = e.parentElement) ancestors.push(geometry(e));
              return { selector, outerHTML: root.outerHTML, ancestors, descendants: [...root.querySelectorAll('*')].map(geometry) };
            });
            window.__pulseDiag.states.push({ stage: 'collectTexts', ms: performance.now(), scrollX, scrollY, viewport: [innerWidth, innerHeight], readyState: document.readyState, result, roots,
              styles: [...document.styleSheets].map(sheet => { try { return { href: sheet.href, disabled: sheet.disabled, rules: [...sheet.cssRules].map(r => r.cssText) }; } catch(error) { return {href: sheet.href, error: error.message}; } }),
              initialization: { expanded: typeof liveEditionExpanded === 'undefined' ? null : liveEditionExpanded, activeTime: typeof activePulseTime === 'undefined' ? null : activePulseTime, bodyClass: document.body.className },
              resources: performance.getEntriesByType('resource').map(r => ({ name: r.name, startTime: r.startTime, duration: r.duration })) });
            return result;
          }, { source: fn.toString(), arg });
          return result;
        };
        const locator = page.locator.bind(page);
        page.locator = (...args) => {
          const loc = locator(...args);
          if (['#cityPulseStart', '#cityPulseTeaser'].includes(args[0])) {
            const screenshot = loc.screenshot.bind(loc);
            loc.screenshot = async (...params) => {
              const buffer = await screenshot(...params);
              const count = (await evaluate(() => {
                const root = document.querySelector('#cityPulseStart');
                window.__pulseDiag.states.push({ stage: 'after-screenshot', ms: performance.now(), scrollX, scrollY, root: root.getBoundingClientRect().toJSON(), headline: document.querySelector('#cityPulseHeadline').getBoundingClientRect().toJSON() });
                return window.__pulseDiag.states.length;
              }));
              fs.writeFileSync(path.join(dir, `page-${id}-audit-${count}.png`), buffer);
              return buffer;
            };
          }
          return loc;
        };
      });
      const close = ctx.close.bind(ctx);
      ctx.close = async (...args) => {
        for (const page of ctx.pages()) {
          try {
            fs.writeFileSync(path.join(dir, `page-${id}.json`), JSON.stringify(await page.evaluate(() => window.__pulseDiag), null, 2));
            await page.screenshot({ path: path.join(dir, `page-${id}-rendered.png`), fullPage: true, timeout: 5000 });
            fs.writeFileSync(path.join(dir, `page-${id}.html`), await page.content());
          } catch (error) { mark('capture_error', { text: error.message }); }
        }
        await Promise.all(bodies);
        fs.writeFileSync(path.join(dir, `page-${id}-events.json`), JSON.stringify(events, null, 2));
        return close(...args);
      };
      return ctx;
    };
    return browser;
  };
}
