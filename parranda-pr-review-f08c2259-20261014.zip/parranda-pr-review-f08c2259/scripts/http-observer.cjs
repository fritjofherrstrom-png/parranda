'use strict';
if (require('node:path').basename(process.argv[1] || '') === 'landing-v2-route.test.js') {
 const fs = require('node:fs'), path = require('node:path'), http = require('node:http');
 const folder = path.join(process.env.PARRANDA_DIAG_RUN_DIR, 'http');
 fs.mkdirSync(folder, { recursive: true });
 const records = [];
 const save = () => fs.writeFileSync(path.join(folder, `landing-${process.pid}.json`), JSON.stringify(records, null, 2) + '\n');
 const listen = http.Server.prototype.listen;
 http.Server.prototype.listen = function(...args) {
  this.once('listening', () => { records.push({ kind: 'server_listening', address: this.address() }); save(); });
  return listen.apply(this, args);
 };
 const get = http.get;
 http.get = function(...args) {
  const options = args[0];
  const record = { kind: 'request', host: options?.hostname || options?.host, port: options?.port, path: options?.path };
  records.push(record);
  const req = get.apply(this, args);
  req.on('socket', socket => {
   const capture = () => { record.socket = { local_address: socket.localAddress, local_port: socket.localPort, remote_address: socket.remoteAddress, remote_port: socket.remotePort }; save(); };
   if (socket.connecting) socket.once('connect', capture); else capture();
  });
  req.on('response', response => { record.status = response.statusCode; save(); });
  req.on('error', error => { record.error = { code: error.code, message: error.message, first_response_bytes: error.rawPacket?.subarray(0,80).toString('utf8') }; save(); });
  return req;
 };
 process.on('exit', save);
}
