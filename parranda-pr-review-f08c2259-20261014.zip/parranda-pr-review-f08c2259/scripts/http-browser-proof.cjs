'use strict';
// External verifier of a frozen repository. Does not modify source or build.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),http=require('node:http'),crypto=require('node:crypto');
const {once}=require('node:events'),{execFileSync}=require('node:child_process');
const {fixtures,deferred,DATE,NOW}=require('./http-fixtures.cjs');
const HEAD='f08c2259df1d9e38d29d68c4b139f35f87978d6e',TREE='0360c5f6d1b0aae512166e91e18bf160980590b0';
const repo=process.env.PARRANDA_REVIEW_REPO;assert.ok(repo,'set PARRANDA_REVIEW_REPO to an exact clean checkout');
const output=process.env.PARRANDA_REVIEW_OUT||path.join(__dirname,'http-'+Date.now());
fs.mkdirSync(output);const {chromium}=require(path.join(repo,'node_modules/playwright-core'));
const {buildApp}=require(path.join(repo,'server/app'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function identity(){assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),HEAD);assert.equal(execFileSync('git',['rev-parse','HEAD^{tree}'],{cwd:repo,encoding:'utf8'}).trim(),TREE);assert.equal(execFileSync('git',['status','--porcelain'],{cwd:repo,encoding:'utf8'}).trim(),'');}
function safePath(raw){return new URL(raw,'http://localhost').pathname.replace(/(\/api\/planner-(?:status|cancel)\/?)[^/]+$/,'$1[opaque]');}
function safeQuery(q){return {scope:q?.scope,time:q?.time,selected_date:q?.selected_date,place:q?.place,dates:q?.dates,preferences:q?.preferences,public_coordinates_present:Boolean(q&&('lat'in q||'lng'in q)),route_point_count:q?.route_points?.length};}
function safeBody(b){return {error:b?.error,live_pending:b?.live_events?.pending,selected_date:b?.live_events?.selected_date,source_health:b?.live_events?.acquisition?.source_health?.status,completion_state:b?.live_completion?.state,capability_present:Boolean(b?.live_completion?.token),route_upgrade:b?.live_completion?.route_upgrade,upgrade_state:b?.live_route_upgrade?.state,day_count:b?.days?.length,selected_day_group_count:b?.live_events?.tonight?.length,week_group_count:b?.live_events?.this_week?.length};}
async function waitFor(label,condition){const until=performance.now()+15000;while(!condition()){assert.ok(performance.now()<until,label+' exceeded existing 15000ms browser budget');await new Promise(r=>setTimeout(r,25));}}
async function post(origin,url,value,raw=false){const response=await fetch(origin+url,{method:'POST',headers:{'Content-Type':'application/json'},body:raw?value:JSON.stringify(value)});const text=await response.text();let body;try{body=JSON.parse(text);}catch{}return {status:response.status,body,headers:response.headers};}
async function frames(page){await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));}
async function saved(page){return page.evaluate(()=>JSON.parse(localStorage.getItem('parranda:anywhere:last'))?.safeResponse?.days);}
async function settledDay(page){await page.waitForFunction(()=>{const d=document.querySelector('[role="dialog"]');return d&&[...d.querySelectorAll('button')].some(b=>b.textContent.trim()==='Sun 25 Oct'&&b.getAttribute('aria-pressed')==='true')&&!d.innerText.includes('Refreshing verified sources for this area');});await frames(page);}
async function expand(dialog){for(const summary of await dialog.locator('details > summary').all())if((await summary.innerText()).trim()==='2 occurrences')await summary.click();}
let browser;const results=[];
async function runCase(mode){
 const f=fixtures(repo),app=buildApp(f.options),backend=http.createServer(app),backendRequests=[],wire=[],errors=[];
 backend.on('request',(req,res)=>{const u=new URL(req.url,'http://localhost');if(!u.pathname.startsWith('/api/'))return;let chunks=[];const row={sequence:backendRequests.length+1,path:safePath(req.url),method:req.method,prefer:req.headers.prefer||null};backendRequests.push(row);req.on('data',c=>chunks.push(c));req.on('end',()=>{try{row.input=safeQuery(JSON.parse(Buffer.concat(chunks)));}catch{row.invalid_json=true;}});res.on('finish',()=>row.status=res.statusCode);});
 backend.listen(0,'127.0.0.1');await once(backend,'listening');
 const barrier={armed:false,held:false,gate:deferred(),arrived:deferred(),released:false,aborted:false,delivered:false};
 const proxy=http.createServer((req,res)=>{
  const parts=[];req.on('data',b=>parts.push(b));req.on('end',()=>{
   const body=Buffer.concat(parts);let query;try{query=JSON.parse(body);}catch{}
   const row={sequence:wire.length+1,path:safePath(req.url),method:req.method,input:safeQuery(query)};wire.push(row);
   const upstream=http.request({hostname:'127.0.0.1',port:backend.address().port,path:req.url,method:req.method,headers:{...req.headers,host:'127.0.0.1:'+backend.address().port}},incoming=>{
    const data=[];incoming.on('data',b=>data.push(b));incoming.on('end',async()=>{
     const bytes=Buffer.concat(data);let result;try{result=JSON.parse(bytes);}catch{}
     row.status=incoming.statusCode;row.output=safeBody(result);
     const hold=barrier.armed&&!barrier.held&&row.path==='/api/live-events'&&query?.time==='this_week'&&result?.live_events?.coverage==='covered'&&result.live_events.pending!==true&&result.live_events.acquisition?.source_health?.status==='healthy'&&result.live_events.this_week.length>0;
     if(hold){barrier.held=true;row.held=true;row.unchanged_body_sha256=sha(bytes);barrier.body=result;barrier.row=row;res.on('close',()=>{if(!res.writableEnded){barrier.aborted=true;row.client_aborted=true;}});res.writeHead(incoming.statusCode,incoming.headers);res.write(bytes.subarray(0,16));barrier.arrived.resolve();await barrier.gate.promise;barrier.released=true;row.released=true;if(!res.destroyed){res.end(bytes.subarray(16));barrier.delivered=true;row.delivered=true;}else row.delivered=false;
     }else if(!res.destroyed){res.writeHead(incoming.statusCode,incoming.headers);res.end(bytes);}
    });
   });upstream.on('error',error=>{row.transport_error=error.code;if(!res.destroyed){res.statusCode=502;res.end('fixture transport failure');}});upstream.end(body);
  });
 });proxy.listen(0,'127.0.0.1');await once(proxy,'listening');const origin='http://127.0.0.1:'+proxy.address().port;
 const ctx=await browser.newContext({viewport:{width:390,height:844},timezoneId:'Europe/Stockholm'}),page=await ctx.newPage();page.setDefaultTimeout(15000);await page.clock.setFixedTime(new Date(NOW));
 // Only remote HTTPS assets are blocked. Product API requests remain real HTTP.
 await ctx.route('https://**/*',route=>route.abort());
 if(mode==='manual-late-json')await ctx.addInitScript(()=>{
  // Explicit adversarial transport: for week fetches only, omit network signal.
  // Original AbortController still marks the obsolete logical request aborted.
  // No API response/content is replaced; native fetch and native json are used.
  window.__reviewTransport=[];const nativeFetch=window.fetch.bind(window);
  window.fetch=async(input,options)=>{let q;try{q=JSON.parse(options?.body);}catch{}const target=String(input).startsWith('/api/live-events')&&q?.time==='this_week';const result=await nativeFetch(input,target?{...options,signal:undefined}:options);if(target){const json=result.json.bind(result);result.json=async()=>{const value=await json();window.__reviewTransport.push({kind:'real_week_json_resolved',pending:value?.live_events?.pending,source_rows:value?.live_events?.this_week?.length});return value;};}return result;};
 });
 let loads=0,initial,capability,completionReady=false;const observed=[],observationTasks=new Set();page.on('domcontentloaded',()=>loads++);page.on('pageerror',error=>errors.push(error.message));
 page.on('response',response=>{const p=new URL(response.url()).pathname;if(!p.startsWith('/api/'))return;const work=(async()=>{try{const value=await response.json();observed.push({path:safePath(response.url()),status:response.status(),output:safeBody(value)});if((p==='/api/route-recommendations'||p.startsWith('/api/planner-status'))&&value.days){initial=value;capability=value.live_completion?.token;}if(p==='/api/planner-live-completion'&&value.live_completion?.state==='ready')completionReady=true;}catch{observed.push({path:safePath(response.url()),status:response.status(),body_unavailable:true});}})();observationTasks.add(work);work.finally(()=>observationTasks.delete(work));});
 const caseDir=path.join(output,mode);fs.mkdirSync(caseDir);
 try{
  assert.equal((await post(origin,'/api/live-events','{broken',true)).status,400,'express.json middleware really rejects malformed JSON');
  assert.equal((await post(origin,'/api/planner-live-completion',{token:'invalid',extra:true})).status,400,'real completion request-shape guard');
  assert.equal((await fetch(origin+'/server/app.js')).status,404,'real private-source access gate');
  await page.goto(origin+'/anywhere?place=Testville&prefs=food,culture,views&lang=en');
  await waitFor('actual planner day and server-issued capability',()=>initial&&capability);
  assert.equal(initial.live_events.pending,true);assert.equal(initial.live_events.selected_date,DATE);assert.ok(initial.agnostic_route_output_experiment.promotion.promote);
  assert.equal(initial.days[0].primary_route.main_stops.filter(s=>s.type==='beach').length,0);
  await page.waitForFunction(()=>Boolean(JSON.parse(localStorage.getItem('parranda:anywhere:last'))?.safeResponse?.days));await frames(page);const before=await saved(page);assert.deepEqual(before,initial.days);
  await page.getByRole('button',{name:'Explore live',exact:true}).click();const dialog=page.getByRole('dialog');await dialog.waitFor();
  const day=dialog.getByRole('button',{name:'Sun 25 Oct',exact:true}),week=dialog.getByRole('button',{name:'Following 7 days',exact:true});assert.equal(await day.getAttribute('aria-pressed'),'true');
  await waitFor('browser actual pending completion response',()=>observed.some(r=>r.path==='/api/planner-live-completion'&&r.status===202&&r.output.live_pending));
  const pending=await post(origin,'/api/planner-live-completion',{token:capability});assert.equal(pending.status,202);assert.equal(pending.headers.get('cache-control'),'no-store');
  if(mode!=='automatic')await day.click();
  f.release();await waitFor('browser ready completion',()=>completionReady);
  await waitFor('all original producer jobs settled',()=>f.collections.length>0&&wire.some(r=>r.path==='/api/planner-live-route-upgrade'&&r.status===200));
  if(mode==='automatic'){
   await page.waitForFunction(()=>[...document.querySelectorAll('[role="dialog"] button')].some(b=>b.textContent.trim()==='Following 7 days'&&b.getAttribute('aria-pressed')==='true'));
   await dialog.getByText('Local workshop series',{exact:true}).first().waitFor();await expand(dialog);assert.match(await dialog.innerText(),/27 Oct/i);assert.match(await dialog.innerText(),/1 Nov/i);await frames(page);
  }else{
   await settledDay(page);await waitFor('actual terminal wider-area fallback',()=>wire.some(r=>r.path==='/api/live-events'&&r.input.scope==='in_place'&&r.output?.source_health==='healthy'));await frames(page);assert.equal(await day.getAttribute('aria-pressed'),'true');assert.match(await dialog.innerText(),/Nothing verified Sun 25 Oct/);
   barrier.armed=true;await week.click();await waitFor('actual terminal weekly HTTP body held',()=>barrier.held);
   assert.deepEqual(barrier.body.live_events.this_week.map(row=>row.title).sort(),['Far workshop series','Local workshop series'],'actual obsolete handler body has two source series');
   await day.click();await settledDay(page);await dialog.getByRole('button',{name:'Near the route',exact:true}).click();await settledDay(page);await dialog.getByText('One event is listed in the following 7 days.',{exact:false}).waitFor();assert.equal(await day.getAttribute('aria-pressed'),'true');assert.equal(await dialog.getByRole('button',{name:'Near the route',exact:true}).getAttribute('aria-pressed'),'true');
   if(mode==='manual-cancellation')await waitFor('obsolete body cancelled before release',()=>barrier.aborted);
   barrier.gate.resolve();await waitFor('obsolete actual body release accounted',()=>barrier.released);
   if(mode==='manual-cancellation'){await waitFor('obsolete body cancelled',()=>barrier.aborted);assert.equal(barrier.delivered,false);}
   else {await page.waitForFunction(()=>window.__reviewTransport.some(x=>x.kind==='real_week_json_resolved'&&x.pending!==true&&x.source_rows>0));assert.equal(barrier.delivered,true);assert.equal(barrier.aborted,false);}
   await frames(page);await settledDay(page);assert.equal(await day.getAttribute('aria-pressed'),'true');assert.match(await dialog.innerText(),/One event is listed in the following 7 days\./);assert.doesNotMatch(await dialog.innerText(),/2 events are listed/,'stale two-source around-place body must not replace the one-source route projection');
  }
  assert.deepEqual(await saved(page),before,'ready completion/live projection preserves the published day');
  const collectionCount=f.collections.length;
  await dialog.getByRole('button',{name:'Close live',exact:true}).click();await page.getByRole('button',{name:'See all live',exact:true}).click();
  if(mode==='automatic'){await page.getByRole('dialog').getByText('Local workshop series',{exact:true}).first().waitFor();assert.equal(await page.getByRole('dialog').getByRole('button',{name:'Following 7 days',exact:true}).getAttribute('aria-pressed'),'true');}
  else {await settledDay(page);assert.equal(await page.getByRole('dialog').getByRole('button',{name:'Sun 25 Oct',exact:true}).getAttribute('aria-pressed'),'true');assert.equal(await page.getByRole('dialog').getByRole('button',{name:'Near the route',exact:true}).getAttribute('aria-pressed'),'true');assert.match(await page.getByRole('dialog').innerText(),/One event is listed in the following 7 days\./);}
  await frames(page);assert.equal(f.collections.length,collectionCount,'reopen is same-cell warm cache');assert.deepEqual(await saved(page),before);
  assert.equal(loads,1);assert.equal(backendRequests.filter(r=>r.path==='/api/route-recommendations').length,1);assert.deepEqual(errors,[]);
  const routeRequest=backendRequests.find(r=>r.path==='/api/route-recommendations');assert.equal(routeRequest.input.place,'Testville');assert.equal(routeRequest.input.public_coordinates_present,false);assert.equal(routeRequest.prefer,'respond-async');
  const ready=await post(origin,'/api/planner-live-completion',{token:capability});assert.equal(ready.status,200);assert.equal(ready.body.live_completion.state,'ready');assert.equal(ready.body.live_events.acquisition.source_health.status,'healthy');
  const slots=[...ready.body.live_events.this_week,...(ready.body.live_events.browse?.this_week?.more||[])].flatMap(row=>row.occurrences?.length?row.occurrences:[row]);
  assert.deepEqual(slots.filter(row=>row.title==='Local workshop series').map(row=>row.time_window.dates[0]).sort(),['2026-10-27','2026-11-01']);assert.ok(slots.every(row=>row.route_eligible===false));
  assert.ok(!JSON.stringify(await page.evaluate(()=>Object.fromEntries(Object.entries(localStorage)))).includes(capability),'actual server bearer never persisted');
  const result={mode,ok:true,head:HEAD,tree:TREE,browser:browser.version(),real_http_backend:true,real_endpoint_handlers_and_middleware:true,product_api_response_replacements:0,source_boundary:'synthetic published Sitevision HTML; real provider/collector/cache',resolver_boundary:'server-owned synthetic resolver',weather_boundary:'synthetic rain',document_loads:loads,route_requests:1,pending_to_ready:true,automatic_week:mode==='automatic',manual_day_preserved:mode!=='automatic',published_day_preserved:true,reopen_preserves_cell:true,reopen_warm_cache:true,stale_body:mode==='automatic'?null:{sha256:barrier.row.unchanged_body_sha256,old_week_group_count:barrier.body.live_events.this_week.length,old_titles:barrier.body.live_events.this_week.map(row=>row.title).sort(),current_route_week_group_count:1,released:barrier.released,delivered:barrier.delivered,client_aborted:barrier.aborted,late_real_json_resolved:mode==='manual-late-json'},route_upgrade_states:wire.filter(r=>r.path==='/api/planner-live-route-upgrade').map(r=>r.output.upgrade_state),provider_collection_count:f.collections.length,source_requests:f.sourceRequests,provider_collections:f.collections,boundary_counts:f.counts(),backend_requests:backendRequests,wire_responses:wire,observed_browser_api:observed,browser_errors:errors};
  assert.ok(result.route_upgrade_states.length>0);assert.ok(result.route_upgrade_states.every(state=>state==='not_eligible'),'real upgrade gate retains future long series as Pulse-only');
  await page.screenshot({path:path.join(caseDir,'live-390.png')});fs.writeFileSync(path.join(caseDir,'rendered.html'),await page.content());fs.writeFileSync(path.join(caseDir,'result.json'),JSON.stringify(result,null,2)+'\n');results.push(result);console.log(JSON.stringify({mode,ok:true,real_http_backend:true,stale_body:result.stale_body}));
 }catch(error){fs.writeFileSync(path.join(caseDir,'failure.json'),JSON.stringify({mode,error:error.message,body:await page.locator('body').innerText(),backendRequests,wire,observed,errors},null,2));await page.screenshot({path:path.join(caseDir,'failure.png'),fullPage:true}).catch(()=>{});throw error;}
 finally{f.release();barrier.gate.resolve();await ctx.close();proxy.closeAllConnections();backend.closeAllConnections();await Promise.all([new Promise(r=>proxy.close(r)),new Promise(r=>backend.close(r))]);await Promise.allSettled([...observationTasks]);f.dispose();}
}
(async()=>{identity();browser=await chromium.launch({...(process.env.PARRANDA_TEST_CHROMIUM?{executablePath:process.env.PARRANDA_TEST_CHROMIUM}:{}),headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});for(const mode of ['automatic','manual-cancellation','manual-late-json'])await runCase(mode);identity();fs.writeFileSync(path.join(output,'HTTP_RESULT.json'),JSON.stringify({head:HEAD,tree:TREE,ok:true,cases:results.length,results,node:process.version,platform:process.platform+'/'+process.arch,source_unchanged:true,verifier_sha256:sha(fs.readFileSync(__filename)),fixtures_sha256:sha(fs.readFileSync(path.join(__dirname,'http-fixtures.cjs'))),whole_suite_rerun:false,evidence:'Real local buildApp HTTP handlers/middleware and built browser UI, controlled external provider/resolver/weather; transparent wire delay and separately declared cancellation fault injection, not live-provider or deployed acceptance.'},null,2)+'\n');})().catch(error=>{console.error(error.stack);process.exitCode=1;}).finally(async()=>{await browser?.close();});
