'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const DATE = '2026-10-25', NOW = '2026-10-25T08:00:00Z', ANCHOR = {lat:55.6,lng:13};
function deferred(){let resolve;const promise=new Promise(r=>resolve=r);return {promise,resolve};}
function pages(){
 const result=new Map();const dates=['2026-10-01','2026-10-27','2026-11-01','2026-11-10'];
 const entries=[{id:'local',title:'Local workshop series',coordinate:'55.601, 13.001'},{id:'far',title:'Far workshop series',coordinate:'55.622, 13.014'}];
 const items=entries.map(({id,title,coordinate})=>{
  const state={id,title,metadata:{dateRange:{date:dates[0]},occasions:dates.map(date=>({date,time:'12:30 – 15:30',location:'Town hall'})),locations:[{name:'Town hall',coordinate,adress:'Main street 4'}]}};
  result.set(`https://municipality.example/event?id=${id}`,`<div class="sv-se-soleil-eventShowcase" data-cid="p"></div><script>AppRegistry.registerInitialState('p',${JSON.stringify(state)});</script><script>AppRegistry.registerApp({portletId:'p',webAppId:'se.soleil.eventShowcase',requiredLibs:{}});</script>`);
  return `<article class="item-${id}"><a href="/event?id=${id}"><h2>${title}</h2></a><time class="dates-kempox" datetime="2026-10-01">1 oktober – 10 november</time><dl><dt>Tid</dt><dd></dd><dt>Kategori</dt><dd>Workshop</dd><dt>Lokal</dt><dd>Town hall</dd></dl></article>`;
 });
 result.set('https://municipality.example/calendar',`<main class="sv-se-soleil-eventListingLocal">${items.join('')}</main>`);return result;
}
function fixtures(repo){
 const {collectAnchorEvents,resolveDefaultEventSupply}=require(path.join(repo,'server/place-candidates/agnostic-event-supply'));
 const {externalRecord}=require(path.join(repo,'tests/helpers/planner-reservoir-compare'));
 const gate=deferred(),documents=pages(),sourceRequests=[],collections=[];
 const cacheDir=fs.mkdtempSync(path.join(os.tmpdir(),'parranda-http-review-'));
 const feed={id:'http-review-calendar',adapter:'sitevision_calendar',endpoint:'https://municipality.example/calendar',timezone:'Europe/Stockholm',bbox:[12.9,55.5,13.1,55.7],source_tier:'official',source_scoped_pulse:true,detail_limit:8};
 const eventSupply=resolveDefaultEventSupply({PARRANDA_AGNOSTIC_EVENTS:'enabled',PARRANDA_EVENT_READER:'disabled',PARRANDA_EVENT_FEEDS:JSON.stringify([feed]),PARRANDA_CACHE_DIR:cacheDir},{eventReader:null,requestTimeDiscovery:null,collectEvents:async args=>{
  assert.equal(args.eventReader,null);collections.push({time:args.time,selectedDate:args.selectedDate,radiusM:args.radiusM});
  return collectAnchorEvents({...args,fetcher:async url=>{await gate.promise;const key=String(url);assert.ok(documents.has(key),'only controlled external source pages');sourceRequests.push(key);return {ok:true,status:200,text:async()=>documents.get(key)};}});
 }});
 const rows=[externalRecord('b1','Bathing one','beach',55.603,13.005,['coast']),externalRecord('b2','Bathing two','beach',55.605,13.006,['coast']),externalRecord('food','Lunch','restaurant',55.601,13.001,['mat']),externalRecord('m1','Museum one','museum',55.602,13.002,['museum']),externalRecord('m2','Museum two','museum',55.604,13.002,['museum']),externalRecord('view','Lookout','viewpoint',55.608,13.008,['utsikt'])];rows.at(-1).sources=rows.at(-1).sources.slice(0,1);
 let loaderCalls=0,weatherCalls=0;
 return {eventSupply,sourceRequests,collections,release:()=>gate.resolve(),options:{eventSupply,openDataLoader:async()=>{loaderCalls++;return rows;},weatherProvider:async()=>{weatherCalls++;return {condition:'rain',source:'fixture',stale:false};},placeResolver:async query=>[{...ANCHOR,label:'Testville',confidence:'high',provenance:'nominatim_osm',query,timezone:'Europe/Stockholm',spatial_scope:{source:'resolver_bounds',kind:'settlement',bounds:{south:55.59,north:55.635,west:12.99,east:13.025}}}],reviewedPlaceSource:null,sourceCatalog:null,placeSuggestions:null,clock:{now:()=>NOW}},counts:()=>({loaderCalls,weatherCalls}),dispose:()=>{gate.resolve();fs.rmSync(cacheDir,{recursive:true,force:true});}};
}
module.exports={fixtures,deferred,DATE,NOW,ANCHOR};
