from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
manifest=json.loads((root/'MANIFEST.json').read_text())
expected={r['path'] for r in manifest['files']}|{'MANIFEST.json','SHA256SUMS'}
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
assert actual==expected, 'Missing or extra files: '+str(actual^expected)
for r in manifest['files']:
 p=root/r['path']; assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'], r['path']
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('Verified',len(manifest['files']),'files plus manifest; exact head',manifest['head'])
