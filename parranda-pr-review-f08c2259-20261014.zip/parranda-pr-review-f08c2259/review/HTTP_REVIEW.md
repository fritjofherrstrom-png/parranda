# Oberoende HTTP-/browserreview

Reviewer: integration_review. Root skrev och körde den externa harnessen. Reviewern läste kod, resultat och renderad HTML samt inspekterade de tre sparade browserbilderna; inga egna test-/browserkörningar eller sourceändringar utfördes.

**Bedömning: inga kvarstående actionable fynd i det avgränsade HTTP-provet eller tidigare whole-diff-review på f08.**

## Exakt identitet

- Kandidat: `f08c2259df1d9e38d29d68c4b139f35f87978d6e`.
- Tree: `0360c5f6d1b0aae512166e91e18bf160980590b0`.
- Bas: `1b047f5e20bef2a4ad06533a7ce6f6644b8bff2d`.
- `http-browser-proof.cjs` SHA-256: `428c0b1ba47ac7d54b4ea9517e5bb6d5df8a721a288058e975ccb56fb7926c83`.
- `http-fixtures.cjs` SHA-256: `26f8563e13e910fd952d0a8459812f486563d77f352f12927964ad029aaa5e69`.

Reviewerns egna checksumläsningar matchar körversionerna registrerade i `http-final/HTTP_RESULT.json`. Egen Git-avstämning visar exakt head/tree, ren worktree och ingen output från bas→head `git diff --check`.

## Faktisk produktkoppling och observerad coverage

Browsern läser byggd Astro/React-UI från vanlig `buildApp`. En loopbackproxy vidarebefordrar verkliga HTTP-requests till appens ordinarie handlers och middleware. Produkt-API-svar ersätts inte av `context.route`, genererade fixturepayloads eller en separat completion store. `buildApp` äger composition, token, completion och route-upgrade. Den verkliga `resolveDefaultEventSupply` → `collectAnchorEvents` → Sitevision-provider/parser/normalizer/fusion/cachekedjan använder syntetisk publicerad source-HTML vid outbound fetch-gränsen. Resolver, platsrecords och väder är serverägda syntetiska externa gränser.

Det lästa slutresultatet innehåller tre PASS-fall:

1. **Automatic:** verklig HTTP completion går från 202/pending till 200/ready. Vald dag behålls medan supply är pending; färdiga faktiska framtidsrader ger automatisk week. Oct27/Nov1 kontrolleras genom normaliserade source-tillfällen och genom expanderad renderad UI före reopen. Publicerad `LAST_KEY`-dag och week-cellen består efter reopen.
2. **Manual cancellation:** explicit dagval görs under pending och består efter terminal completion/sheet/wider-area-svar. En verklig around-place-week-kropp hålls efter headers. Harnessen kräver exakt grupperna `Far workshop series` och `Local workshop series` innan release. Browserabort observeras före release; kroppen levereras inte. Den nya near-route-dagcellen behåller vald period, rätt scope och previewn för en framtidsserie även efter reopen.
3. **Manual late JSON:** samma gamla tvågruppskropp levereras efter den nya near-route-dagcellen. Separat deklarerad fault injection utelämnar bara nätverkssignalen för week-fetches; produktens AbortController och native fetch/json används fortsatt. Faktiskt sent upplöst JSON observeras. Den gamla kroppen ersätter inte den nya cellens en-gruppsprojektion, period eller scope. Detta är ett adversarial transportprov, separat från vanlig cancellation.

Båda manualfallen loggar samma oförändrade gamla kroppshash, `af0ed4ad55d21244b9a748e4ae968d4bd81ab867d801095fe9d421e7cd96e5ba`, två gamla gruppidentiteter och verkliga terminala near-route-svar med en grupp. Renderad copy och sparade bilder överensstämmer med dag×near-route och "One event is listed in the following 7 days." efter release/reopen.

Alla tre fallen har en dokumentladdning, en riktig planeringsbegäran med `Prefer: respond-async`, en platsloader- och en väderläsning, bevarad publicerad dag och inga registrerade `pageerror`-exceptions. Completiontoken kommer från riktig HTTP-response och finns inte i browserns localStorage. Reopen återanvänder samma cell utan ny producer-collection. Period-/scopebyten får fortfarande samla nya pooler enligt befintlig cacheidentitet; provet påstår inte att sådana byten är kostnadsfria. Verkliga negativa HTTP-fall verifierar malformed JSON→400, otillåten completion-requestform→400 och privat source-path→404.

## Avslutade reviewnoteringar och gränser

Tidigare externa harnessnoteringar är korrigerade: snapshot väntar på publicerad `LAST_KEY`-dag; minst ett rått serverstate `not_eligible` krävs; cancellationobservering föregår release; terminal state behandlar utelämnat `pending` korrekt; den gamla tvågruppskroppen är explicit verifierad före den kvantitativa stale-assertionen. Inga produktändringar behövdes.

Den långa serien är avsiktligt Pulse-only: `route_eligible=false`, och riktig route-upgrade svarar `not_eligible`. Detta HTTP-prov bevisar **ingen applied day upgrade**. Sådan coverage är separat från dessa fall. Ny fullsvit har inte körts för den externa harnessförstärkningen.

Tidigare whole-diff-review inkluderade hela bas→f08-diffen och exakt f08:s sex förstärkningsrader: `LAST_KEY`-import, faktiskt publicerad dag jämförd med JSON-snapshot före Live samt samma publicerade dag kontrollerad efter completion/automatisk week. Denna bedömning återanvänds eftersom source/head/tree är oförändrade.

Miljön är lokal Node v24.15.0 på Darwin/arm64 och Chrome 155.0.8059.40, med 390-pixels viewport. HTTPS-browserassets utanför lokala appen blockeras. Resultatet är inte live-provider-/kalenderrecall-, kartnavigation-, Safari-, Linux/Node22-, Pi- eller deployad/stagingacceptans. Selected-day-vyn utan bekräftade tillfällen bevisar inte att inget händer den dagen. v13-cacheinvalidering och övriga produktregressioner hör till tidigare committed focused/full-evidens; den nya HTTP-harnessen tillför verklig endpoint-/middleware- och transport/livscykelcoverage.
