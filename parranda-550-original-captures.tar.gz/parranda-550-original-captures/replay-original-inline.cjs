const fs=require('node:fs');
const assert=require('node:assert/strict');
const {createHash}=require('node:crypto');
const {createScheduledEventCardProvider}=require('./server/pulse-sources/scheduled-event-card-provider');
const captures=JSON.parse(fs.readFileSync('/tmp/parranda-scheduled-calendar-provenance.json','utf8'));
const saved=new Map(captures.map(c=>{
 const body=fs.readFileSync(c.path,'utf8');
 assert.equal(createHash('sha256').update(body).digest('hex'),c.sha256);
 return[c.url,body];
}));
const calls=[];
const fetcher=async url=>{
 calls.push(url);assert.ok(saved.has(url),`uncaptured fetch ${url}`);
 return{ok:true,status:200,url,headers:{get:()=>null},text:async()=>saved.get(url)};
};
(async()=>{
 const result=await createScheduledEventCardProvider({endpoint:captures[1].url,timezone:'Europe/Brussels',sourceLanguage:'nl',detailLimit:2,fetcher}).create({key:'anywhere'}).collect({now:'2026-10-04T09:00:00Z'});
 assert.equal(result.collection_status.status,'ok');assert.equal(result.time_sensitive_events.length,2);assert.equal(calls.length,4);
 for(const event of result.time_sensitive_events){assert.equal(event.country,'BE');assert.equal(event.starts_at,undefined);assert.equal(event.ends_at,undefined);assert.equal(event.lat,undefined);assert.equal(event.recurrence,undefined);}
 fs.writeFileSync('/tmp/parranda-550-block-boundaries-replay.json',JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({collection:result.collection_status,events:result.time_sensitive_events.map(({title,address,starts_on,country})=>({title,address,starts_on,country}))}));
})().catch(error=>{console.error(error);process.exitCode=1});
