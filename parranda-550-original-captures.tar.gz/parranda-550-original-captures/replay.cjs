"use strict";

// Portable packaging of the inline replay in this chat. Read only the saved
// capture bytes; never fetch their source URLs or start the application.
const assert = require("node:assert/strict");
const { createHash } = require("node:crypto");
const { execFileSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");

async function main() {
  const args = process.argv.slice(2);
  assert.ok(args.length === 2 && args[0] === "--repo", "usage: node replay.cjs --repo /absolute/path/to/frozen-parranda-checkout");
  const repo = path.resolve(args[1]);
  const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, "capture-manifest.json"), "utf8"));
  const repoSha = execFileSync("git", ["-C", repo, "rev-parse", "HEAD"], { encoding: "utf8" }).trim();
  assert.equal(repoSha, manifest.replay.repo_sha, "use the exact frozen checkout recorded in capture-manifest.json");
  assert.ok(Number(process.versions.node.split(".")[0]) >= 22, "Node 22 or newer required");

  require(path.join(repo, "tests/helpers/no-live-network.js"));
  globalThis.fetch = () => assert.fail("live fetch is forbidden by this offline replay");
  const { createScheduledEventCardProvider } = require(path.join(repo, "server/pulse-sources/scheduled-event-card-provider"));
  const saved = new Map();
  const hashes = {};
  for (const capture of manifest.captures) {
    const bytes = fs.readFileSync(path.join(__dirname, capture.file));
    const digest = createHash("sha256").update(bytes).digest("hex");
    assert.equal(bytes.length, capture.bytes, capture.file);
    assert.equal(digest, capture.sha256, capture.file);
    hashes[capture.file] = digest;
    saved.set(capture.url, bytes.toString("utf8"));
  }
  const calls = [];
  const fetcher = async (url) => {
    calls.push(url);
    assert.ok(saved.has(url), `uncaptured URL cannot be fetched: ${url}`);
    return { ok: true, status: 200, url, headers: { get: () => null }, text: async () => saved.get(url) };
  };
  const result = await createScheduledEventCardProvider({
    endpoint: manifest.replay.endpoint,
    timezone: manifest.replay.timezone,
    sourceLanguage: manifest.replay.source_language,
    detailLimit: manifest.replay.detail_limit,
    fetcher,
  }).create({ key: "anywhere" }).collect({ now: manifest.replay.now });
  assert.deepEqual(calls, manifest.captures.map((capture) => capture.url));
  assert.equal(result.collection_status.status, "ok");
  assert.equal(result.time_sensitive_events.length, 2);
  for (const event of result.time_sensitive_events) {
    assert.equal(event.country, "BE");
    assert.equal(event.starts_on, "2026-10-04");
    assert.equal(event.starts_at, undefined);
    assert.equal(event.ends_at, undefined);
    assert.equal(event.lat, undefined);
    assert.equal(event.lng, undefined);
    assert.equal(event.recurrence, undefined);
  }
  assert.deepEqual(result, JSON.parse(fs.readFileSync(path.join(__dirname, "expected-replay.json"), "utf8")));
  process.stdout.write(JSON.stringify({
    repo_sha: repoSha,
    node: process.version,
    offline: true,
    replay_now: manifest.replay.now,
    verified_sha256: hashes,
    calls,
    result,
  }, null, 2) + "\n");
}

main().catch((error) => { console.error(error); process.exitCode = 1; });
