# PR #550 original capture handoff

These are the four complete saved response-body files used by Codex's offline
replay. They are binary copies of the originals, not structural excerpts and
not fresh downloads. Capture dates below are the original UTC capture dates.

`capture-manifest.json` records relative paths, source URLs, byte counts,
original capture timestamps and SHA-256 hashes. `provenance-original.json`
retains the original provenance record, including its old `/tmp` paths.
`SHA256SUMS` checks every delivered file except the checksum list itself.

## Offline replay

Use an existing Parranda checkout at exactly:

```
0465366f52a094880d94f85333b4b0335b13055e
```

Node 22+ and the repository's locked dependencies must already be installed.
This replay does not install dependencies, fetch source pages, write the Source
Catalog or start any web/worker service.

From this extracted directory:

```sh
sha256sum -c SHA256SUMS
node replay.cjs --repo /absolute/path/to/that/parranda-checkout > replay-result.json
```

The script verifies the repository SHA and each original capture's byte count
and hash before parsing. Only the four recorded URLs can be requested, and
those requests are served from local bytes by the fixture-backed fetcher.
The real provider runs with `detailLimit: 2`, timezone `Europe/Brussels`, source
language `nl` and fixed `now: 2026-10-04T09:00:00Z`, matching the earlier replay.
The result must match `expected-replay.json` exactly: two date/address rows,
published BE country, unknown hours and no inferred coordinates/recurrence.
This fixed clock replays the capture; it is not a claim about today's events.

## Script provenance

The earlier replay was executed as a Node heredoc in this Codex chat, rather
than saved as a standalone script. `replay-original-inline.cjs` transcribes
that executed source, including its original `/tmp` input/output paths and
relative module import. Its original invocation, from the frozen repo, was:

```sh
node --require ./tests/helpers/no-live-network.js - < /path/to/replay-original-inline.cjs
```

For another host, use `replay.cjs`. It packages the same hash checks, local
fixture-backed fetcher and actual-provider invocation with relative archive
paths, an explicit checkout argument, a revision guard and comparison with the
saved expected output. It does not substitute or regenerate any capture.

No merge, deployment, runtime QA, geocoding, source permission or broad European
coverage is established by this evidence transfer. PR #550's implementation
head and the included #548 ancestry are unchanged by publishing the archive.
